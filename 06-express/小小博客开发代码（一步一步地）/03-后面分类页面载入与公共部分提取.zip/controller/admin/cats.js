var express = require('express');
var router = express.Router();

// 渲染后台分类列表页面
router.get('/', function (req, res, next) {
    res.render("admin/category_list")
});

// 渲染后台添加分类页面
router.get('/add', function (req, res, next) {
    res.render("admin/category_add")
});

// 渲染后台修改分类页面
router.get('/edit', function (req, res, next) {
    res.render("admin/category_edit")
});

module.exports = router;
